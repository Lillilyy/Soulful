import time

from PIL import Image

def compress_image(source,dest,width):
    im = Image.open(source)
    x,y = im.size
    if x>width:
        ys = int(y*width/x)
        xs = width
        temp = im.resize((xs,ys),Image.ANTIALIAS)
        temp.save(dest,quality=80)
        
    else:
        im.save(dest,quality=80)

#从文章解析图片地址
def parse_image_url(content):
    import re
    temp_list = re.findall('<img .*?src="(.+?)"',content)
    url_list = []
    for url in temp_list:
        if url.lower().endswith('.gif'):
            continue
        if url.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            url_list.append(url)
        else:
            url_list.append(url)
    return url_list

#远程下载指定url地址图片，并保存到临时目录
def download_image(url,dest):
    import requests
    response = requests.get(url)
    with open(file=dest,mode='wb') as file:
        file.write(response.content)

#生成缩略图
def generate_thumb(url_list):
    for url in url_list:
        if url.startswith('/static/upload'):
            filename = url.split('/')[-1]
            compress_image('./static/upload/'+filename,'./static/thumb/'+filename,400)
            return filename

    url = url_list[0]
    filename = url.split('/')[-1]
    suffix = filename.split('.')[-1]
    thumbname = time.strftime('%Y%m%d_%H%M%S.'+suffix)
    download_image(url,'./static/download/'+thumbname)
    compress_image('./static/download/'+thumbname,'./static/thumb/'+thumbname,400)

    return thumbname


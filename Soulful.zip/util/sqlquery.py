import random
import time

from flask import session
from flask_login import current_user

from appweb.models import *
from util.recommd import recommend


class Article_query():
    def find_all(self,page,per_page):    #获取所有文章

        articles = Article.query.filter_by(hidden=0,drafted=0,checked=1,).order_by(Article.articleid.desc())
        print("articles", articles)

        return articles.paginate(page=page, per_page=per_page)


    def find_type(self,typeid,page,per_page):    #获取类型文章

        articles = Article.query.filter_by(hidden=0,drafted=0,checked=1,typeid=typeid).order_by(Article.articleid.desc())
        return articles.paginate(page=page, per_page=per_page)


    def search_keyword(self,keyword,page,per_page):  #关键字获取文章

        articles = Article.query.filter_by(hidden=0,drafted=0,checked=1).filter(Article.headline.like('%'+keyword+'%')).order_by(Article.articleid.desc())
        return articles.paginate(page=page, per_page=per_page)

#最新文章
    def find_new_9(self):
        articles = Article.query.filter_by(hidden=0,drafted=0,checked=1).order_by(Article.articleid.desc()).limit(9).all()
        return articles

#最多阅读
    def find_readmost(self):
        articles = Article.query.filter_by(hidden=0, drafted=0, checked=1).order_by(Article.readcount.desc()).limit(
            9).all()
        return articles

#未登入最多推荐
    def find_remmend(self):
        if current_user.is_authenticated:
            # 根据协同过滤推荐
            articles = recommend(current_user.id)
            if articles:
                if len(articles) > 10:
                    return articles[:9]
                return articles
            else:
                return None
        articles = Article.query.filter_by(hidden=0, drafted=0, checked=1, recommended=1).order_by(
            Article.articleid.desc()).limit(
            9).all()
        return articles





    def find_side_info(self):   #侧边栏信息
        news = self.find_new_9()
        readmost = self.find_readmost()
        remmend = self.find_remmend()
        news_articles = []
        readmost_articles = []
        remmend_articles = []
        for new in news:
            dic = []
            dic.append(new.articleid)
            dic.append(new.headline)
            news_articles.append(dic)
        for new in readmost:
            dic = []
            dic.append(new.articleid)
            dic.append(new.headline)
            readmost_articles.append(dic)
        if remmend:
            for new in remmend:
                dic = []
                dic.append(new.articleid)
                dic.append(new.headline)
                remmend_articles.append(dic)
        else:
            remmend_articles = []
        return news_articles,remmend_articles,readmost_articles

    def find_article(self,articleid):
        article = Article.query.filter_by(articleid=articleid,drafted=0).first()
        return article

#跟新阅读次数
    def update_readcount(self,articleid):
        article = Article.query.filter_by(articleid=articleid).first()
        article.readcount += 1
        db.session.commit()

    def update_comment_count(self,articleid):
        article = Article.query.filter_by(articleid=articleid).first()
        article.replycount += 1
        db.session.commit()

#是否支付过积分
    def find_pay(self,articleid):
        if current_user.is_authenticated:
            pay = Credt.query.filter_by(userid=current_user.id,target=articleid).first()
            payed = True if pay else False
            return payed
        payed = False
        return payed

    #下一篇文章
    def find_next_article(self,articleid):
        article = Article.query.filter(Article.hidden==0,Article.drafted==0,Article.checked==1,Article.articleid>articleid)\
            .order_by(Article.articleid).limit(1).first()
        if article:
            return article
        return self.find_article(articleid)

    #上一篇文章
    def find_pret_article(self,articleid):
        article = Article.query.filter(Article.hidden == 0, Article.drafted == 0, Article.checked == 1,
                                       Article.articleid < articleid) \
            .order_by(Article.articleid.desc()).limit(1).first()

        if article:
            return article
        return self.find_article(articleid)
#保存草稿
    def insert_article(self,type,headline,content,thumbnail,credit,drafted,checked):
        now = datetime.now()
        article = Article(userid=current_user.id,typeid=type,headline=headline,content=content,thumbnail=thumbnail,
                          credit=credit,drafted=drafted,checked=checked,createtime=now,updatetime=now)
        db.session.add(article)
        db.session.commit()

#找草稿
    def find_drafte(self,id):
        article = Article.query.filter_by(articleid=id,drafted=1).first()
        return article

#更新草稿
    def update_drafte(self,id,type,headline,content,thumbnail,credit,drafte,checked):
        article = Article.query.filter_by(articleid=id, drafted=1).first()
        article.typeid = type;article.headline = headline;article.content = content
        article.thumbnail = thumbnail;article.credit = credit
        db.session.commit()

    # 发表草稿
    def to_post(self,id,type,headline,content,thumbnail,credit,drafted,checked):
        article = Article.query.filter_by(articleid=id, drafted=1).first()
        article.drafted = drafted;article.typeid = type;article.headline = headline;article.content = content
        article.thumbnail = thumbnail;article.credit = credit;article.checked = checked
        db.session.commit()

#文章一半展示与全展示
    def show_artilce(self,articleid):
        dic = {}
        article = self.find_article(articleid)
        payed = self.find_pay(articleid)
        next_article = self.find_next_article(articleid)
        pret_article = self.find_pret_article(articleid)
        comments = Comment_query().model_reply_comments(articleid)
        position = None
        for k, v in article.__dict__.items():
            if not k.startswith('_sa_instance_state'):
                dic[k] = v
        dic['nickname'] = article.user.nickname
        dic['type'] = article.type.type
        if current_user.is_authenticated:
            if payed or article.credit == 0:
                return dic, comments, position, payed, next_article, pret_article
        content = article.content
          # 截取文章一半
        position = content.rfind('</p>', 0, int(len(content) / 2))
        if position != -1:
            position += 4
            dic['content'] = content[:position]
        else:
            print("没有找到 '</p>' 标签")
            position = int(len(content) / 2)
            dic['content'] = content[:position]
        comments = None
        return  dic,comments,position,payed,next_article,pret_article

#返回最新文章id
    def find_most_articleid(self):
        article = Article.query.order_by(Article.articleid.desc()).first()
        if article:
            return article.articleid
        return 0

    # 文章删除
    def article_detele(self,id):
        artilce = Article.query.filter_by(articleid=id).first()
        db.session.delete(artilce)
        db.session.commit()
#文章隐藏
    def article_hidden(self,id):
        article = Article.query.filter_by(articleid=id).first()
        # article.hidden =1
        db.session.delete(article)
        db.session.commit()

    # 文章显示
    def article_show(self,id):
        article = Article.query.filter_by(articleid=id).first()
        article.hidden =0
        db.session.commit()



class User_query():
    def save_user(self,username,password):   #注册成功用户保存
        avatar = random.randint(1,15)
        nickname = username.split('@')[0]
        user = User(username=username,avatar=f'{avatar}.png',credit=100,nickname=nickname,createtime=datetime.utcnow(),updatetime=datetime.utcnow())
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        session['userid'] = user.id

    def info_credit(self,category,target,credit):    #插入积分信息
        # now = time.strftime('%Y-%m-%m %H:%M:%S')
        now = datetime.now()
        user = User.query.order_by(User.id.desc()).first()
        id = user.id
        articles = User.query.all()
        for k, v in articles[-1].__dict__.items():
            if k=="userid":
                id = v
        credit = Credt(userid=id,category=category,target=target,credit=credit,createtime=now,updatetime=now)
        db.session.add(credit)
        db.session.commit()

    def find_user(self,username):
        user = User.query.filter_by(username=username).first()
        return user

    def update_credt(self,user,score):  #更新个人积分
        user.credit += int(score)
        if user.credit <0:
            return False
        db.session.commit()
        return True
#重置密码
    def reset_password(self,pwd,userid):
        user = User.query.filter_by(id=userid).first()
        user.set_password(pwd)
        db.session.commit()
#更新用户信息
    def update_user_info(self,username,nickname,qq):
        current_user.username = username
        current_user.nickname = nickname
        current_user.qq = qq
        db.session.commit()

class Favorite_query():
    #检查是否收藏
    def check_favorite(self,articleid):
        if current_user.is_authenticated:
            fav = Favorite.query.filter_by(articleid=articleid,userid=current_user.id,canceled=0).first()
            if fav:
                return True
            return False
        return False

    def check_like(self,articleid):
        if current_user.is_authenticated:
            like = Like.query.filter_by(article_id=articleid,user_id=current_user.id).first()
            if like:
                return True
            return False
        return False
#插入收藏
    def insert_favorite(self,articleid):
        fav = Favorite.query.filter_by(articleid=articleid,userid=current_user.id).first()
        if fav:
            fav.canceled = 0
            db.session.commit()
        else:
            fav = Favorite(articleid=articleid,userid=current_user.id)
            db.session.add(fav)
            db.session.commit()
#取消收藏
    def canceled_favorite(self,articleid):
        fav = Favorite.query.filter_by(articleid=articleid, userid=current_user.id).first()
        fav.canceled = 1
        db.session.commit()


class Comment_query():
#获取文章前几条评论
    def find_all_comments(self,articleid):
        comments = Comment.query.filter_by(articleid=articleid,hidden=0,replyid=0).order_by(Comment.commentid.desc()).all()
        return comments

#插入评论
    def insert_comment(self,articleid,content,ipaddr):
        now = datetime.now()
        comment = Comment(articleid=articleid,userid=current_user.id,content=content,ipaddr=ipaddr,createtime=now,updatetime=now)
        db.session.add(comment)
        db.session.commit()

#检测评论是否限制
    def check_comment_limit5(self):
        now = datetime.now().date()
        end_date = datetime.strftime(now, "%Y-%m-%d 23:59:59")
        start_date = datetime.strftime(now, "%Y-%m-%d %H:%M:%S")
        comments = Comment.query.filter(Comment.userid==current_user.id,Comment.createtime.between(start_date,end_date)).all()
        if current_user.role =='admin':
            return True
        if len(comments)>=5:
            return False
        return True
#保存回复评论
    def insert_reply_comment(self,articleid,content,ipaddr,replyid):
        now = datetime.now()
        comment = Comment(articleid=articleid,userid=current_user.id,content=content,ipaddr=ipaddr,replyid=replyid,createtime=now,updatetime=now)
        db.session.add(comment)
        db.session.commit()
#获取回复评论
    def find_reply_comment(self,replyid):
        comments = Comment.query.filter_by(hidden=0, replyid=replyid).order_by(
        Comment.commentid.desc()).all()
        return comments
#序列化
    def model_list(self,models):
        list = []
        for model in models:
            dic = {}
            for k, v in model.__dict__.items():
                if not k.startswith('_sa_instance_state'):
                    dic[k] = v
            dic['nickname'] = model.user.nickname
            list.append(dic)
        return list

    def model_reply_comments(self,articleid):
        comments = self.find_all_comments(articleid)
        comments_list = self.model_list(comments)
        for comment in comments_list:
            result = self.find_reply_comment(comment['commentid'])
            comment['reply'] = self.model_list(result)
        return comments_list

#根据评论id隐藏
    def hide_comment(self,commentid):
        comment = Comment.query.filter_by(commentid=commentid).first()
        comment.hidden = 1
        db.session.commit()

    # 根据评论id显示评论
    def show_comment(self, commentid):
        comment = Comment.query.filter_by(commentid=commentid).first()
        comment.hidden = 0
        db.session.commit()
#赞同评论
    def agree_comment(self,commentid):
        comment = Comment.query.filter_by(commentid=commentid).first()
        comment.agreecount += 1
        db.session.commit()
#反对评论
    def disagree_comment(self,commentid):
        comment = Comment.query.filter_by(commentid=commentid).first()
        comment.opposecount += 1
        db.session.commit()

#管理员查询
class admin_query():
    def find_all_user(self):
        users = User.query.all()
        return users

    def find_all_artices(self):
        artices = Article.query.filter_by(checked=1).all()
        return artices

    def find_all_comments(self):
        comments = Comment.query.all()
        return comments

    def find_all_unchecked(self):
        uncheckeds = Article.query.filter_by(checked=0).all()
        return uncheckeds

    def find_all_types(self):
        types = Type.query.all()
        return types

    def check(self,id):
        article = Article.query.filter_by(articleid=id).update({'checked':1})
        db.session.commit()

    def recommend(self,id):
        article = Article.query.filter_by(articleid=id).update({'recommended':1})
        db.session.commit()

    def detele_user(self,id):
        user = User.query.filter_by(id=id).first()
        db.session.delete(user)
        db.session.commit()

    def add_user(self,username,nickname,credit,password):
        user = User(username=username,nickname=nickname,credit=credit)
        user.set_password(password)
        db.session.commit()

    def add_type(self,type):
        type1 = Type(type=type)
        db.session.add(type1)
        db.session.commit()

   #推荐加分
class RatingService:
    def add_score(self, article_id, action):
        # 查找对应文章的评分记录
        article_rating = Rating.query.filter_by(article_id=article_id).first()

        if article_rating:
            # 如果评分记录存在，根据不同的行为给文章加分
            if action == 'read':
                article_rating.view_score += 1  #阅读加分
                article_rating.total_score += 1
            elif action == 'like':
                article_rating.like_score += 1
                article_rating.total_score += 2  # 点赞加2分
            elif action == 'favorite':
                article_rating.collect_score += 1
                article_rating.total_score += 2  # 收藏加2分
            elif action == 'comment':
                article_rating.comment_score += 1
                article_rating.total_score += 2  # 评论加2分
        else:
            # 如果评分记录不存在，创建新的评分记录，并根据行为设置相应的加分
            article_rating = Rating(article_id=article_id)
            if action == 'read':
                article_rating.view_score = 1  #阅读加分
                article_rating.total_score = 1
            elif action == 'like':
                article_rating.like_score = 1
                article_rating.total_score = 2  # 点赞加2分
            elif action == 'favorite':
                article_rating.collect_score = 1
                article_rating.total_score = 2  # 收藏加2分
            elif action == 'comment':
                article_rating.comment_score = 1
                article_rating.total_score = 2  # 评论加2分

            db.session.add(article_rating)

        # 提交数据库事务
        db.session.commit()

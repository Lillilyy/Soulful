import random
import smtplib
import string
from email.mime.text import MIMEText
from email.header import Header

from appweb import app


def send_mail(receiver,code,flag):
    account= app.config['MAIL_USERNAME']
    password = app.config['MAIL_PASSWORD']
    mailhost = 'smtp.163.com'
    qqmail = smtplib.SMTP_SSL(mailhost,app.config['MAIL_PORT'])
    qqmail.login(account, password)
    if flag=='reg':
        content = f'您正在申请注册账号，您的验证码是{code}'
    elif flag == 'reset':
        content = f'您正在申请重置密码，您的验证码是{code}'
    else:
        content = '您已经成功操作,欢迎使用博客'
    message = MIMEText(content, 'plain', 'utf-8')
    subject = '博客注册'
    message['Subject'] = Header(subject, 'utf-8')
    message['From'] = Header(account)
    message['To'] = Header(receiver)
    qqmail.sendmail(account, receiver, message.as_string())
    qqmail.quit()

def get_random_string():
    str = random.sample(string.ascii_letters+string.digits,6)
    return ''.join(str)
import os

from appweb import db
from appweb.models import User, Rating, Article
from math import *

def getdata():#获取数据
    data_list = db.session.query(Rating.user_id, Rating.article_id, Rating.total_score).all()

    # 如果你想要将结果转换成字典列表，可以使用字典推导式
    alldata = [[item[0], item[1],item[2]] for item in data_list]
    data={}
    for i in alldata:
        if not i[0] in data.keys():
            data[i[0]]={i[1]:i[2]}
        else:
            data[i[0]][i[1]]=i[2]
    return data

#计算用户相似度
def Euclid(user1,user2):#尤几里得距离也就是欧式距离
    #取出两个用户都查看过的的博客
    data=getdata()
    print(data)
    print('data',data)
    user1_data=data[user1]
    user2_data=data[user2]
    #默认距离,相似度越大距离越短
    distance=0
    #遍历找出相同职位
    for key in user1_data.keys():
        if key in user2_data.keys():
            distance+=pow(float(user1_data[key])-float(user2_data[key]),2)
    return 1/(1+sqrt(distance))
#计算某用户和其他用户相似度的比对
def top_simliar(user):
    res=[]
    data=getdata()
    for userid in data.keys():
        #首先排除当前用户
        if not userid==user:
            simliar=Euclid(user,userid)
            res.append((userid,simliar))
    res.sort(key=lambda val:val[1])
    return res,data
def recommend(id):#给用户推荐方法
    #print(top_simliar(id))
    user = User.query.get(id)
    data = getdata()
    if id not in data.keys():
        return None
    res,data=top_simliar(id)
    print('res+data',res,data)
    workid={}
    try:
        for i in range(5):
            top_user=res[i][0]
            #print(top_user)
            #print(data[top_user])
            workid.update(data[top_user])
    except:
        pass
    #print(workid)
    worklist=[]
    workid=sorted(workid.items(),key=lambda x:x[1],reverse=True)[:10]#给职位列表按打分排序,取出前十个推荐
    for i in workid:
        worklist.append(i[0])
    print(worklist)
    workdeilt = db.session.query(Article).filter(Article.articleid.in_(worklist)).all()
    print('worklist',worklist)
    return workdeilt

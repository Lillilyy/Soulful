import sqlite3
import random
from datetime import datetime, timedelta

def update_user_timestamps(db_file):
    # 连接到SQLite数据库
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()

    try:
        # 获取当前时间
        now = datetime.now()

        # 为每个用户生成最近两天内的随机时间
        cursor.execute("SELECT id FROM user;")
        user_ids = cursor.fetchall()

        for user_id in user_ids:
            # 生成随机时间偏移量（0到48小时之间）
            random_hours = random.uniform(0, 48)
            random_minutes = random.uniform(0, 60)
            random_seconds = random.uniform(0, 60)

            # 计算随机时间
            random_time = now - timedelta(hours=random_hours,
                                          minutes=random_minutes,
                                          seconds=random_seconds)

            # 格式化时间为SQLite接受的格式
            formatted_time = random_time.strftime("%Y-%m-%d %H:%M:%S.%f")

            # 更新数据库
            cursor.execute("""
                UPDATE user 
                SET createtime = ?, updatetime = ?
                WHERE id = ?
            """, (formatted_time, formatted_time, user_id[0]))

        # 提交事务
        conn.commit()
        print(f"成功更新了{len(user_ids)}条用户记录的时间戳")

        # 验证更新结果
        cursor.execute("SELECT id, username, createtime, updatetime FROM user;")
        updated_users = cursor.fetchall()

        print("\n更新后的用户时间信息:")
        for user in updated_users:
            print(f"ID: {user[0]}, 用户名: {user[1]}, 创建时间: {user[2]}, 更新时间: {user[3]}")

    except sqlite3.Error as e:
        print(f"数据库错误: {e}")
        conn.rollback()
    finally:
        # 关闭连接
        conn.close()

# 使用示例
if __name__ == "__main__":
    db_file = "data.sqlite"  # 替换为你的数据库文件路径
    update_user_timestamps(db_file)
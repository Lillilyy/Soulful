from flask import url_for, render_template
from werkzeug.utils import redirect
from appweb import app, db

@app.route('/')
def hello_world():
    return redirect(url_for('index.index'))
 
@app.template_filter('strftime')
def _jinja2_filter_datetime(date, fmt=None):
    if fmt is None:
        fmt = '%Y-%m-%d %H:%M:%S'
    return date.strftime(fmt)

@app.template_filter('md')
def markdown_to_html(txt):
    from markdown import markdown
    return markdown(txt)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html',error=error)

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html',error=error)

if __name__ == '__main__':

    app.run(port=5004)

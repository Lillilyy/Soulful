import pandas as pd

from main import db
from appweb.models import User,Article, Credt,Comment,Type
# import pandas as pd
# import pymysql
import sqlite3
from datetime import datetime
from main import app

# num1 = User.query.filter_by(username='786120564@qq.com').detele()
# num1.username = '786120563@qq.com'
# db.session.commit()
with app.app_context():
    user = User.query.filter_by(username='britlee').first()
    user.set_password('123456')
    db.session.commit()
# db.drop_all()
# db.create_all()
# articles = Article.query.all()
# for article in articles:
#     print(article)
#     article.thumbnail = 'thumb.png'
#     db.session.commit()
# comments = Comment.query.filter_by(articleid=122,hidden=0,replyid=0).order_by(Comment.commentid.desc()).limit(9)
# for comment in comments:
#     print(comment.content)
# conn = pymysql.connect(host="localhost", user="root",password="786120564",db="weiboke",charset="utf8",port=3306,)
# cursor = conn.cursor()
# cursor.execute("select * from article;")
# res = cursor.fetchall()
#
# conn1 = sqlite3.connect('data.sqlite')
# cursor1 = conn1.cursor()
# for i in res:
#     # list1 = list(i)
#     # del list1[2]
#     cursor1.execute("insert into article values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",i)
#     conn1.commit()
# type = ['前端','数据库','爬虫','数据分析','机器学习']
# for i in range(5):
#
#     # cursor1.execute("insert into type values (%d,'%s')"%(i+1,type[i]))
#     sql = "insert into type (typeid,type) values (?,?)"
#     cursor1.execute(sql,(i+1,type[i]))
#     conn1.commit()
# cursor1.close()
# conn1.close()

# user = User(username='bruce@qq.com',nickname='bruce',avatar='4.png',qq='786102555',role='user',
#             credit='100',createtime=datetime.utcnow(),updatetime=datetime.utcnow())
# user.set_password('britney994711')
# db.session.add(user)
# db.session.commit()
# articles = Article.query.all()
# for k,v in articles[1].__dict__.items():
#     print(k,v)
    # print(article.headline,article.user.nickname)


# grade1 = Grade(score="80",student_id='1',course_id='1')
# grade2 = Grade(score="95",student_id='4',course_id='3')
# grade3 = Grade(score="92",student_id='5',course_id='3')
# grade4 = Grade(score="78",student_id='4',course_id='1')
# grade5 = Grade(score="80",student_id='6',course_id='2')
# grade6 = Grade(score="59",student_id='5',course_id='4')
# db.session.add_all([grade1, grade2, grade3, grade4, grade5, grade6])
# db.session.commit()

# stu = Student.query.get(1)
# stu = Student.query.filter(Student.id==1).first()
# stu1 = Student.query.filter_by(id=1).first()
# stus = Student.query.all()
# num = Student.query.filter_by(gender='男').update({'gender':'女'})
# num1 = Grade.query.filter_by(student_id=None).delete()
# db.session.commit()
# print(stu.name,num)
# for stu in stus:
#     print(stu.name)

# 一方反问多
# stu = Student.query.get(1)
# print(stu.grades)
# for i in stu.grades:
#     print(i.score,stu.name)

# 多反问1
# grade = Grade.query.get(1)
# print(grade.student.name)

# stu = Student.query.filter(Student.id > 1).all()
# for i in stu.grades:
#     print(i.score)
# cs = Course.query.filter(Course.id > 1).all()
# for i in stu:
#     i.courses = cs
#     db.session.add(i)
#     db.session.commit()
# stu = Student.query.filter(Student.id == 2).first()
# print(stu.name,stu.courses,stu.grades)
# print(stu.name,stu.courses.all(),stu.grades.all())

# grade = Grade.query.filter(Grade.student_id ==1).all()
# print(grade)
# for i in grade:
#     print(i.student_id,i.student.name,i.course_id,i.student.gender,i.score)

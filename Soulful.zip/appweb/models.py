from datetime import datetime

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from appweb import db

# class Type_user():
#     __tablename__ = "type_user"
#     __abstract__ = True
#     articleid = db.Column(db.Integer, db.ForeignKey("article.articleid"))  # 文章的id
#     typeid = db.Column(db.Integer, db.ForeignKey("type.typeid"))  # 类型的id

from sqlalchemy.dialects.mysql import LONGTEXT
class User(UserMixin,db.Model):   #用户表
    __tablename__ = "user"
    id = db.Column(db.Integer,primary_key=True)
    username = db.Column(db.String(64),index=True, unique=True,nullable=False)
    password = db.Column(db.String(128),nullable=False)  #MD5密码
    nickname = db.Column(db.String(64))
    avatar = db.Column(db.String(30),default='1.png')
    qq = db.Column(db.String(30))
    role = db.Column(db.String(30),nullable=False,default='user')  #角色
    credit = db.Column(db.Integer)  #剩余积分
    createtime = db.Column(db.DateTime(40))
    updatetime = db.Column(db.DateTime(40))

    credits = db.relationship('Credt', backref="user", lazy="dynamic")
    articles = db.relationship('Article', backref="user", lazy="dynamic")    #发表文章
    comments = db.relationship("Comment", backref="user", lazy="dynamic")#评论的文章
    favorites = db.relationship("Favorite", backref="user", lazy="dynamic")  #收藏的文章
    likes = db.relationship("Like", backref="user", lazy="dynamic")  #收藏的文章

    def set_password(self,password):
        self.password = generate_password_hash(password)

    def check_password(self,password):
        return  check_password_hash(self.password,password)

class Article(db.Model):  #文章表
    __tablename__ = "article"
    articleid = db.Column(db.Integer,primary_key=True)
    userid = db.Column(db.Integer,db.ForeignKey("user.id",ondelete='CASCADE'))
    # types = db.relationship("Type", secondary="type_user", backref="articles", lazy="dynamic")  #类型
    typeid = db.Column(db.Integer, db.ForeignKey("type.typeid"))  #类型id
    headline = db.Column(db.String(100))  #文章标题
    content  = db.Column(LONGTEXT)
    thumbnail = db.Column(db.String(30))   #文章缩略图
    credit = db.Column(db.Integer,default=0)  #文章消耗的积分数
    readcount = db.Column(db.Integer,default=0) #文章阅读次数
    replycount = db.Column(db.Integer,default=0) #评论回复次数
    recommended = db.Column(db.Integer,default=0) #是否设为推荐文章
    hidden = db.Column(db.Integer,default=0) #文章是否被隐藏
    drafted = db.Column(db.Integer,default=0) #文章是否是草稿
    checked = db.Column(db.Integer,default=0) #文章是否已被审核
    createtime = db.Column(db.DateTime(40),default=datetime.now) #该条数据的新增时间
    updatetime = db.Column(db.DateTime(40)) #该条数据的修改时间

    comments = db.relationship('Comment',backref="article", lazy="dynamic")


class Credt(db.Model):  #积分表
    __tablename__ = "credt"
    creditid = db.Column(db.Integer,primary_key=True)
    userid = db.Column(db.Integer,db.ForeignKey("user.id",ondelete='CASCADE'))
    category = db.Column(db.String(100)) #积分变化的原因说明
    target = db.Column(db.Integer)  #积分新增或消耗对应的目标对象。
    credit = db.Column(db.Integer) #积分的具体数量
    createtime = db.Column(db.DateTime(40),default=datetime.now)
    updatetime = db.Column(db.DateTime(40))


class Type(db.Model):   #文章类型表
    __tablename__ = "type"
    typeid = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(20))
    articles = db.relationship('Article', backref="type", lazy="dynamic")

class Comment(db.Model):
    commentid = db.Column(db.Integer,primary_key=True)
    userid = db.Column(db.Integer,db.ForeignKey("user.id",ondelete='CASCADE'))
    articleid = db.Column(db.Integer,db.ForeignKey("article.articleid",ondelete='CASCADE'))
    content = db.Column(db.TEXT)
    ipaddr = db.Column(db.String(30))
    replyid  = db.Column(db.Integer,default=0) #是否为原始评论及被回复评论的ID号
    agreecount = db.Column(db.Integer,default=0) # 赞同该评论的数量
    opposecount = db.Column(db.Integer,default=0) #反对该评论的数量
    hidden = db.Column(db.Integer,default=0)
    createtime = db.Column(db.DateTime(40),default=datetime.now)
    updatetime = db.Column(db.DateTime(40))

class Favorite(db.Model):
    __tablename__ = "favorite"
    favoriteid = db.Column(db.Integer,primary_key=True)
    articleid = db.Column(db.Integer,db.ForeignKey("article.articleid",ondelete='CASCADE'))
    # typeid = db.Column(db.Integer,db.ForeignKey("type.typeid"))
    userid = db.Column(db.Integer,db.ForeignKey("user.id"))
    canceled = db.Column(db.Integer,default=0)  #收藏是否被取消
    createtime = db.Column(db.DateTime(40), default=datetime.now)
    updatetime = db.Column(db.DateTime(40),default=datetime.now)

#点赞
class Like(db.Model):
    __tablename__ = "like"
    like_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete='CASCADE'))
    article_id = db.Column(db.Integer, db.ForeignKey("article.articleid", ondelete='CASCADE'))
    liked_at = db.Column(db.DateTime(40), default=datetime.now)

#博客推荐分
class Rating(db.Model):
    __tablename__ = "rating"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete='CASCADE'))
    article_id = db.Column(db.Integer, db.ForeignKey("article.articleid", ondelete='CASCADE'))
    like_score = db.Column(db.Integer, default=0)  # 用户点赞得分
    comment_score = db.Column(db.Integer, default=0)  # 用户评论得分
    view_score = db.Column(db.Integer, default=0)  # 用户浏览得分
    collect_score = db.Column(db.Integer, default=0)  # 用户收藏得分
    total_score = db.Column(db.Integer, default=0)  # 总得分
    timestamp = db.Column(db.DateTime, default=datetime.now)
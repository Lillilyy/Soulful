from flask import Flask, render_template, redirect, url_for
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
import os
from settings import Config
# appweb = Flask(__name__,static_folder='appweb/static',template_folder='appweb/templates',static_url_path='/')
app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config.from_object(Config)
db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_ = LoginManager(app)
login_.login_view = 'auth.login'

from appweb.index import ind
from appweb.errors import bp
from appweb.author import auth
from appweb.article import art
from appweb.ueditor import ueditor
from appweb.users import user
from appweb.Admin import Admin

app.register_blueprint(ind, url_prefix='/index')
# app.register_blueprint(bp, url_prefix='/error')
app.register_blueprint(auth, url_prefix='/auth')
app.register_blueprint(art, url_prefix='/article')
app.register_blueprint(ueditor, url_prefix='/ueditor')
app.register_blueprint(user, url_prefix='/user')
app.register_blueprint(Admin, url_prefix='/admin')


from flask import Blueprint, render_template, jsonify, request, redirect, abort, session

from appweb.models import User
from util.sqlquery import admin_query
from util.time import striftime
from flask_login import login_required, LoginManager, current_user, login_user

Admin = Blueprint('admin', __name__)

@Admin.route('/',methods=['GET','POST'])
@login_required
def admin():
    if session.get('admin'):
        return render_template('admin/admin.html')
    return redirect('/admin/login')


@Admin.route('/login',methods=['GET','POST'])
def admin_login():
    if request.method=='GET':
        return render_template('admin/admin_login.html')
    user = request.form.get('user')
    pwd = request.form.get('pwd')
    code = request.form.get('code')
    admin = User.query.filter_by(role='admin').first()
    if user==admin.username and admin.check_password(pwd):
        if code.upper() == session['image'].upper():
            login_user(admin)
            session['admin'] = user
            return redirect('/admin')
        error = '验证码错误'
        return render_template('admin/admin_login.html',error=error)
    error = '用户名或者密码错误'
    return render_template('admin/admin_login.html',error=error)



@Admin.route('/get/user',methods=['GET','POST'])
@login_required
def admin_user():
    users = admin_query().find_all_user()
    data = []
    for user in users:
        list = [user.id,user.username,user.nickname,user.role,user.credit,striftime(user.createtime)]
        data.append(list)
    return jsonify({'msg':True,'data':data,'head':'用户管理'})

@Admin.route('/get/article',methods=['GET','POST'])
@login_required
def admin_article():
    articles = admin_query().find_all_artices()
    data = []
    for article in articles:
        id = article.articleid
        list = [id,article.headline,article.user.username,article.type.type,article.readcount,article.replycount,striftime(article.createtime),article.hidden]
        data.append(list)
    return jsonify({'msg':True,'data':data,'head':'发布文章管理'})

@Admin.route('/get/checked',methods=['GET','POST'])
@login_required
def admin_checked():
    articles = admin_query().find_all_unchecked()
    data = []
    for article in articles:
        list = [article.articleid,article.headline,article.user.username,article.type.type,striftime(article.createtime)]
        data.append(list)
    return jsonify({'msg':True,'data':data,'head':'待审文章管理'})

@Admin.route('/get/comments',methods=['GET','POST'])
@login_required
def admin_comments():
    comments = admin_query().find_all_comments()
    data = []
    for comment in comments:
        list = [comment.commentid,comment.user.nickname,comment.article.headline,comment.content,comment.ipaddr,comment.agreecount,comment.opposecount,striftime(comment.createtime),comment.hidden]
        data.append(list)
    return jsonify({'msg':True,'data':data,'head':'文章评论管理'})

@Admin.route('/get/types',methods=['GET','POST'])
@login_required
def admin_types():
    types = admin_query().find_all_types()
    data = []
    for type in types:
        list = [type.typeid,type.type]
        data.append(list)
    return jsonify({'msg':True,'data':data,'head':'文章类型管理'})


@Admin.route('/check',methods=['GET','POST'])
@login_required
def admin_check():
    id = request.form.get('id')
    admin_query().check(id)
    return jsonify({'msg':True})

@Admin.route('/recommend',methods=['GET','POST'])
@login_required
def admin_recommend():
    id = request.form.get('id')
    admin_query().recommend(id)
    return jsonify({'msg':True})


@Admin.route('/detele/user',methods=['GET','POST'])
@login_required
def admin_detele_user():
    id = request.form.get('id')
    admin_query().detele_user(id)
    return jsonify({'msg':True})


@Admin.route('/add/type',methods=['GET','POST'])
@login_required
def admin_add_types():
    type = request.form.get('type')
    admin_query().add_type(type)
    return jsonify({'msg': True})





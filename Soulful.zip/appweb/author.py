import re
from datetime import datetime, timedelta
from io import BytesIO

from flask_login import login_user, current_user, logout_user, login_required
from werkzeug.urls import url_parse

from appweb.models import *
from flask import Blueprint, url_for, request, jsonify, make_response, session, \
    redirect

from appweb import login_
from util.code import check_code
from util.send_mail import get_random_string, send_mail
from util.sqlquery import User_query

auth = Blueprint('auth', __name__)

@auth.before_request
def before_request():
    if current_user.is_authenticated:
        current_user.updatetime = datetime.now()
        db.session.commit()

@auth.route('/register', methods=['POST'])
def register():
    if current_user.is_authenticated:
        return jsonify({'msg': False, 'error': '用户已登录'})

    email = request.form.get('email')
    pwd = request.form.get('pwd')
    code = request.form.get('code')

    # 验证邮箱格式
    if not email or not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
        return jsonify({'msg': False, 'error': '邮箱格式不正确'})

    # 验证密码格式
    if not pwd or not re.match(r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$', pwd):
        return jsonify({'msg': False, 'error': '密码格式错误，必须包含字母和数字，且长度至少8位'})

    # 验证验证码
    if not session.get('code') or code != session['code']:
        return jsonify({'msg': False, 'error': '验证码错误或已过期'})

    # 验证邮箱是否已注册
    if len(User.query.filter_by(username=email).all()) > 0:
        return jsonify({'msg': False, 'error': '邮箱已经被注册'})

    try:
        user = User_query()
        user.save_user(email, pwd)  # 保存用户到数据库
        user.info_credit('用户注册', 0, 100)  # 增加注册信息
        return jsonify({'msg': True})
    except Exception as e:
        return jsonify({'msg': False, 'error': f'注册失败: {str(e)}'})

@auth.route('/code', methods=['GET'])
def code():
    image, code_str = check_code()
    # 将验证码图片以二进制形式写入在内存中
    buf = BytesIO()
    image.save(buf, 'jpeg')
    buf_str = buf.getvalue()
    # 把二进制作为response发回前端，并设置首部字段
    response = make_response(buf_str)
    response.headers['Content-Type'] = 'image/gif'
    # 将验证码字符串储存在session中
    session['image'] = code_str
    session.permanent = True
    # 设置session过期时间
    auth.permanent_session_lifetime = timedelta(minutes=1)
    return response

@auth.route('/send_email', methods=['POST'])
def send_email_code():
    email = request.form.get('email')
    flag = request.form.get('flag')

    if not email or not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
        return jsonify({'msg': False, 'error': '邮箱格式不正确'})

    code = get_random_string()
    session['code'] = code
    session['email'] = email
    session.permanent = True
    auth.permanent_session_lifetime = timedelta(minutes=1)

    try:
        send_mail(email, code=code, flag=flag)
        return jsonify({'msg': True})
    except Exception as e:
        print(f'邮件发送失败: {e}')
        return jsonify({'msg': False, 'error': '邮件发送失败'})

@login_.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@auth.route('/login', methods=['POST', 'GET'])
def login():
    if current_user.is_authenticated:
        return jsonify({'msg': False, 'error': '用户已登录'})

    email = request.form.get('user')
    pwd = request.form.get('password')
    code = request.form.get('code')

    # 验证验证码
    if not session.get('image') or not code or code.upper() != session['image'].upper():
        return jsonify({'msg': False, 'error': '验证码错误或已过期'})

    use = User_query()
    user = use.find_user(email)

    if not user:
        return jsonify({'msg': False, 'error': '用户不存在'})

    if not user.check_password(pwd):
        return jsonify({'msg': False, 'error': '密码错误'})

    try:
        login_user(user)
        use.info_credit('用户登录', 0, 1)  # 插入记录
        use.update_credt(user, 1)  # 加积分

        next_page = request.args.get('next')
        # 安全验证next参数
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('index.index')

        return jsonify({'msg': True, 'next_page': next_page})
    except Exception as e:
        return jsonify({'msg': False, 'error': f'登录失败: {str(e)}'})

@auth.route('/logout', methods=['POST', 'GET'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('index.index'))

@auth.route('/reset_pass', methods=['POST', 'GET'])
def reset_password():
    email = request.form.get('user')
    pwd = request.form.get('password')
    code = request.form.get('code')

    # 验证密码格式
    if not pwd or not re.match(r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$', pwd):
        return jsonify({'msg': False, 'error': '密码格式错误，必须包含字母和数字，且长度至少8位'})

    # 验证验证码
    if not session.get('code') or not code or code.upper() != session['code'].upper():
        return jsonify({'msg': False, 'error': '验证码错误或已过期'})

    use = User_query()
    user = use.find_user(email)

    if not user:
        return jsonify({'msg': False, 'error': '用户不存在'})

    try:
        use.reset_password(pwd, user.id)
        send_mail(email, code=None, flag='password_reset')

        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('auth.login')  # 重置密码后跳转到登录页

        return jsonify({'msg': True, 'next_page': next_page})
    except Exception as e:
        return jsonify({'msg': False, 'error': f'密码重置失败: {str(e)}'})
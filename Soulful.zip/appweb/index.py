from flask import Blueprint, render_template, current_app, url_for, request, abort, jsonify, redirect
from flask_login import login_required, current_user

from util.sqlquery import *

ind = Blueprint('index', __name__)


@ind.route('/')#主页
def index():
    per_page = current_app.config['POSTS_PER_PAGE']
    page =1
    article = Article_query()
    articles = article.find_all(page,per_page)
    next_url = url_for('index.page', page=articles.next_num) if articles.has_next else None
    prev_url = url_for('index.page', page=articles.prev_num) if articles.has_prev else None
    return render_template('index.html',articles=articles.items,next_url=next_url, prev_url=prev_url,pagination=articles)


@ind.route('/page/<int:page>')  #页码
def page(page):
    per_page = current_app.config['POSTS_PER_PAGE']
    if page:
        article = Article_query()
        articles = article.find_all(page, per_page)
        next_url = url_for('index.page', page=articles.next_num) if articles.has_next else None
        prev_url = url_for('index.page', page=articles.prev_num) if articles.has_prev else None
        return render_template('index.html', articles=articles.items, next_url=next_url, prev_url=prev_url,
                               pagination=articles)

@ind.route('/type/<int:typeid>-<int:page>')  #类型页面
def type(typeid,page):
    per_page = current_app.config['POSTS_PER_PAGE']
    if typeid and page:
        article = Article_query()
        articles = article.find_type(typeid,page,per_page)
        next_url = url_for('index.type', page=articles.next_num,typeid=typeid) if articles.has_next else None
        prev_url = url_for('index.type', page=articles.prev_num,typeid=typeid) if articles.has_prev else None
        return render_template('type.html', articles=articles.items, next_url=next_url, prev_url=prev_url,
                               pagination=articles,typeid=typeid)

@ind.route('/search/<keyword>-<int:page>')
def search(keyword,page):
    per_page = current_app.config['POSTS_PER_PAGE']
    if page and keyword:
        if len(keyword)==0 or len(keyword)>10 or '%' in keyword:
            abort(404)
        article = Article_query()
        articles = article.search_keyword(keyword, page, per_page)
        next_url = url_for('index.search', keyword=keyword, page=page) if articles.has_next else None
        prev_url = url_for('index.search', keyword=keyword, page=page) if articles.has_prev else None

        prev_url = url_for('index.type', keyword=keyword, page=page) if articles.has_prev else None

        return render_template('search.html', articles=articles.items, next_url=next_url, prev_url=prev_url,
                               pagination=articles,keyword=keyword)

#侧边栏信息
@ind.route('/side')
def find_side():
    article = Article_query()
    news, remmends,readmosts = article.find_side_info()
    return jsonify({"news":news,"readmosts":readmosts,"remmends":remmends})

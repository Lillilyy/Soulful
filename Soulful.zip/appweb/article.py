from flask import Blueprint, render_template, abort, request, jsonify
from flask_login import current_user, login_required
from urllib import parse

from appweb import db
from appweb.models import Like
from util.sqlquery import Article_query, User_query, Favorite_query, Comment_query, RatingService
from util.image import compress_image,generate_thumb,parse_image_url,download_image
art = Blueprint('article', __name__)

@art.route('/<int:articleid>',methods=['POST','GET'])
def read_half(articleid):
    fav_cheack = Favorite_query().check_favorite(articleid)
    liked = Favorite_query().check_like(articleid)
    dic, comments, position, payed, next_article, pret_article = Article_query().show_artilce(articleid)
    Article_query().update_readcount(articleid)  # 更新阅读次数
    RatingService().add_score(articleid,'read')  #阅读加文字推荐评分

    return render_template('article.html', article=dic, position=position, payed=payed,fav_cheack=fav_cheack,
                           next_article=next_article,pret_article=pret_article,comments=comments,liked=liked )


@art.route('/read/all',methods=['POST','GET'])
@login_required
def read_all():
    articleid = request.form.get('articleid')
    position = request.form.get('position')
    article = Article_query().find_article(articleid)
    if article:
        content = article.content[int(position):]
        if current_user.is_authenticated:
            flag = User_query().update_credt(current_user,-article.credit)#更新积分信息
            if flag:
                User_query().info_credit('阅读文章',articleid,-article.credit)   #更新积分消耗
                return content
            return None

@art.route('/favorate/<int:articleid>',methods=['POST','GET'])
@login_required
def favorate(articleid, ):
    if current_user.is_authenticated:
        Favorite_query().insert_favorite(articleid)
        RatingService().add_score(articleid, 'favorite')  #收藏加分
        return jsonify({'msg':True})
    return jsonify({'msg': False,'error':'您未登录,不能进行收藏'})

@art.route('/favorate/cancele/<int:articleid>',methods=['POST','GET'])
@login_required
def cancele_favorate(articleid):
    if current_user.is_authenticated:
        Favorite_query().canceled_favorite(articleid)
        return jsonify({'msg': True})
    return jsonify({'msg': False,'error':'您未登录,不能进行收藏'})
# 点赞路由
@art.route('/like_article', methods=['POST'])
def like_article():
    if current_user.is_authenticated:
        article_id = request.form.get('article_id')
        user_id = 1  # 假设用户ID为1，你需要替换为实际的用户ID，可以从当前用户的会话中获取
        RatingService().add_score(article_id, 'like')
        # 检查是否已经点赞过
        existing_like = Like.query.filter_by(user_id=user_id, article_id=article_id).first()

        if existing_like:
            # 如果已经点赞过，取消点赞
            db.session.delete(existing_like)
            db.session.commit()
            return jsonify({'success': True, 'liked': False})
        else:
            # 如果未点赞过，添加点赞记录
            new_like = Like(user_id=user_id, article_id=article_id)
            db.session.add(new_like)
            db.session.commit()
            return jsonify({'success': True, 'liked': True})
    return jsonify({'success': False, 'error': '未登入不能点赞'})
@art.route('/comment',methods=['POST','GET'])
@login_required
def comment():
    content = request.form.get('content')
    articleid = request.form.get('articleid')
    ipaddr = request.remote_addr
    if len(content)<5 or len(content)>500:
        return jsonify({'msg':False,'error':'你输入的评论太短或太长'})
    if Comment_query().check_comment_limit5():
        try:
            Comment_query().insert_comment(articleid,content,ipaddr)
            User_query().info_credit('发表评论',articleid,1)
            User_query().update_credt(current_user,1)
            Article_query().update_comment_count(articleid)
        except:
            return jsonify({'msg': True, 'error': '服务器出错，请联系管理员'})
        RatingService().add_score(articleid, 'comment')  # 评论加分
        return jsonify({'msg':True})
    return jsonify({'msg': True,'error':'你今日评论已超过5条，请休息一下'})

@art.route('/replycomment',methods=['POST','GET'])
@login_required
def replycomment():
    content = request.form.get('content')
    articleid = request.form.get('articleid')
    replyid = request.form.get('replyid')
    ipaddr = request.remote_addr
    if len(content) < 5 or len(content) > 500:
        return jsonify({'msg': False, 'error': '你输入的评论太短或太长'})
    if Comment_query().check_comment_limit5():
        try:
            Comment_query().insert_reply_comment(articleid, content, ipaddr,replyid)
            User_query().info_credit('发表评论', articleid, 1)
            User_query().update_credt(current_user, 1)
            Article_query().update_comment_count(articleid)
        except:
            return jsonify({'msg': False, 'error': '服务器出错，请联系管理员'})
        RatingService().add_score(articleid, 'comment')  # 评论加分
        return jsonify({'msg': True})
    return jsonify({'msg': False, 'error': '你今日评论已超过5条，请休息一下'})

#隐藏评论
@art.route('/hidecomment',methods=['POST','GET'])
@login_required
def hidecomment():
    commentid = request.form.get('commentid')
    try:
        Comment_query().hide_comment(commentid)
        return jsonify({'msg': True})
    except:
        return jsonify({'msg': False})

#点赞评论
@art.route('/agree',methods=['POST','GET'])
def agreecomment():
    commentid = request.form.get('commentid')
    try:
        Comment_query().agree_comment(commentid)
        return jsonify({'msg': True})
    except:
        return jsonify({'msg': False})

   #反对评论
@art.route('/disagree',methods=['POST','GET'])
def disagreecomment():
    commentid = request.form.get('commentid')
    try:
        Comment_query().disagree_comment(commentid)
        return jsonify({'msg': True})
    except:
        return jsonify({'msg': False})

   #草稿箱
@art.route('/post/<int:id>',methods=['POST','GET'])
@login_required
def post_drafte_article(id):
    if id :
        print(id)
        article = Article_query().find_drafte(id)
        return render_template('post_drafte.html',article=article)

@art.route('/post',methods=['POST','GET'])
@login_required
def post_article():
    return render_template('post.html')

@art.route('/insert',methods=['POST','GET'])
@login_required
def insert_article():
    form = request.form.to_dict()
    #解析url编码
    content = parse.unquote(form.get('content'))
    headline = form.get('headline')
    credit = int(form.get('credit'))
    id = form.get('id')
    type = int(form.get('type'))
    url_list = parse_image_url(content)
    if url_list:
        thumbname = generate_thumb(url_list)
    else:
        thumbname = 'thumb.png'
    drafted = int(form.get('drafted'))
    if id:    #草稿保存或者发布
        if drafted == 1:
            Article_query().update_drafte(id,type,headline,content,thumbname,credit,1,0)
            return jsonify({'msg': True})
        if drafted == 0:
            Article_query().to_post(id, type, headline, content, thumbname, credit, 0, 0)
            User_query().info_credit('发表文章', id, 5)
            User_query().update_credt(current_user, 5)
            return jsonify({'msg': True})
#新的文章保存草稿或者发布
    target = Article_query().find_most_articleid()
    Article_query().insert_article(type,headline,content,thumbname,
                                   credit,drafted,form.get('checked'))
    if drafted==0:   #发布文章更新积分
        User_query().info_credit('发表文章',int(target)+1, 5)
        User_query().update_credt(current_user, 5)
    return jsonify({'msg':True})

        # return jsonify({'msg': False})

@art.route('/detele',methods=['POST','GET'])
@login_required
def article_detele():
    id = request.form.get('id')
    Article_query().article_detele(int(id))
    return jsonify({'msg':True})

@art.route('/hidden',methods=['POST','GET'])
@login_required
def article_hidden():
    id = request.form.get('id')
    print(id)
    Article_query().article_hidden(int(id))
    return jsonify({'msg':True})

@art.route('/show',methods=['POST','GET'])
@login_required
def article_show():
    id = request.form.get('id')
    Article_query().article_show(int(id))
    return jsonify({'msg':True})

@art.route('/comment/hidden',methods=['POST','GET'])
@login_required
def comment_hidden():
    id = request.form.get('id')
    Comment_query().hide_comment(int(id))
    return jsonify({'msg':True})

@art.route('/comment/show',methods=['POST','GET'])
@login_required
def comment_show():
    id = request.form.get('id')
    Comment_query().show_comment(int(id))
    return jsonify({'msg':True})
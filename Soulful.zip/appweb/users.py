from util.time import striftime
from flask import Blueprint, render_template, abort, request, jsonify
from flask_login import current_user, login_required
from appweb.models import Article
from util.sqlquery import User_query

user = Blueprint('user', __name__)

@user.route('/info',methods=['GET','POST'])
@login_required
def usercenter():
    return render_template('user/base-user.html')


@user.route('/get/credit',methods=['GET','POST'])
@login_required
def user_get_credit():
    title = [{'title':'积分id'},{'title':'类型'},{'title':'对象'},{'title':'积分数'},{'title':'发布时间'}]
    data = []
    credits = current_user.credits
    for credit in credits:
        if credit.target ==0:
            target = '注册或者登录'
        else:
            target = credit.target
        list =[credit.creditid,credit.category,target, credit.credit, striftime(credit.createtime)]
        data.append(list)
    return jsonify({'msg': True, 'data': data, 'title': title,'head':'我的积分'})

@user.route('/get/favorite',methods=['GET','POST'])
@login_required
def user_get_favorite():
    data = []
    articles = current_user.favorites
    for article in articles:
        id = article.articleid
        art = Article.query.filter_by(articleid=id).first()
        list =[id,art.user.nickname, f'<a href="/article/{id}">{art.headline}</a>',art.type.type, striftime(article.createtime),article.canceled]
        data.append(list)
    return jsonify({'msg': True, 'data': data, 'head':'我的收藏'})


@user.route('/get/article',methods=['GET','POST'])
@login_required
def user_get_artcile():
    data = []
    articles = Article.query.filter_by(userid=current_user.id,drafted =0).all()
    for article in articles:
        list =[article.articleid, article.headline,article.type.type, article.readcount,article.replycount,striftime(article.createtime),article.checked,article.hidden]
        data.append(list)
    return jsonify({'msg': True, 'data': data,'head':'我的文章'})

@user.route('/get/info',methods=['GET','POST'])
@login_required
def get_user():
    data = [];user=current_user
    list = [user.id,user.username,user.nickname,user.qq,user.role,user.credit,striftime(user.createtime)]
    data.append(list)
    return jsonify({'msg':True,'data':data,'head':'我的资料'})


@user.route('/get/comment',methods=['GET','POST'])
@login_required
def user_get_comment():
    data = []
    comments = current_user.comments
    for comment in comments:
        content = comment.content[:30] +'......'
        list =[comment.commentid,f'<a href="/article/{comment.articleid}">{comment.article.headline}</a>', content, comment.agreecount,comment.opposecount,striftime(comment.createtime),comment.hidden]
        data.append(list)
    return jsonify({'msg': True, 'data': data,'head':'我的评论'})

@user.route('/get/drafte',methods=['GET','POST'])
@login_required
def get_user_drafte():
    title = [{'title': '文章编号'}, {'title': '标题'}, {'title': '类型'}, {'title': '发布时间'},{'title': '操作'}]
    data = []
    articles = Article.query.filter_by(userid=current_user.id, drafted=1).all()
    for article in articles:
        list = [article.articleid, f'<a href="/article/{article.articleid}">{article.headline}</a>', article.type.type,
                striftime(article.createtime)]
        data.append(list)
    return jsonify({'msg': True, 'data': data, 'title': title,'head':'我的草稿'})

@user.route('/info/update',methods=['GET','POST'])
@login_required
def user_info_update():
    form = request.form.to_dict()
    User_query().update_user_info(form.get('username'),form.get('nickname'),form.get('qq'))
    return jsonify({'msg':True})

from flask import Blueprint, render_template, abort, request, jsonify
import os
ueditor = Blueprint('ueditor', __name__)

@ueditor.route('/uedit',methods=['GET','POST'])
def uedit():
    param = request.args.get('action')
    if request.method =='GET' and param == 'config':
        return render_template('config.json')
    elif request.method == 'POST' and param =='uploadimage':
        f = request.files['upfile']
        filename = f.filename
        f.save('./static/upload/'+filename)
        result ={}
        result['state'] = 'SUCCESS'
        result['url'] = f'/static/upload/{filename}'
        result['title'] = filename
        result['original'] = filename

        return jsonify(result)
    #列出所有图片给浏览器
    elif request.method == 'GET' and param == 'listimage':
        list = []
        filelist = os.listdir('./static/upload', exist_ok=True)
        for filename in filelist:
            if filename.lower().endswith('.png') or filename.lower().endswith('.jpg'):
                list.append({'url':'/static/upload/%s' %filename})
        result = {}
        result['state'] = 'SUCCESS'
        result['list'] = list
        result['start'] = 0
        result['total'] = 50
        return jsonify(result)
